﻿'use client';

import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  FormControl,
  FormLabel,
  Textarea,
  VStack,
  Text,
  useToast,
  IconButton,
  HStack,
} from '@chakra-ui/react';
import { HiArrowLeft } from 'react-icons/hi';
import { useState } from 'react';
import { useAuth } from '@/shared/lib/auth/auth-context';

interface ConvertToUnqualifiedModalProps {
  isOpen: boolean;
  onClose: () => void;
  leadId: string;
  leadName: string;
  onSuccess?: () => void;
  onBack?: () => void;
}

export default function ConvertToUnqualifiedModal({
  isOpen,
  onClose,
  leadId,
  leadName,
  onSuccess,
  onBack,
}: ConvertToUnqualifiedModalProps) {
  const toast = useToast();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [reason, setReason] = useState('');
  const [competitor, setCompetitor] = useState('');

  const handleSubmit = async () => {
    if (!reason.trim()) {
      toast({
        title: 'Reason required',
        description: 'Please provide a reason for marking as unqualified',
        status: 'warning',
        duration: 3000,
      });
      return;
    }

    if (reason.trim().length < 10) {
      toast({
        title: 'Reason too short',
        description: 'Please provide a detailed reason (at least 10 characters)',
        status: 'warning',
        duration: 3000,
      });
      return;
    }

    setLoading(true);

    try {
      // Update lead status via API with reason in customerRequirement and notes fields
      const notes = competitor
        ? `Marked as Unqualified: ${reason}. Competitor/Notes: ${competitor}`
        : `Marked as Unqualified: ${reason}`;
      
      const response = await fetch(`/api/leads/${leadId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: 'unqualified',
          customerRequirement: reason,
          notes: notes,
          updatedById: user?.id,
        }),
      });

      if (response.ok) {
        toast({
          title: 'Success!',
          description: `${leadName} has been marked as unqualified`,
          status: 'success',
          duration: 3000,
        });

        setReason('');
        setCompetitor('');
        onClose();
        
        // Trigger refresh via callback
        if (onSuccess) {
          onSuccess();
        }
      } else {
        throw new Error('Failed to update lead');
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update lead status',
        status: 'error',
        duration: 3000,
      });
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="md" closeOnOverlayClick={false}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>
          <HStack spacing={2}>
            {onBack && (
              <IconButton
                aria-label="Back"
                icon={<HiArrowLeft />}
                size="sm"
                variant="ghost"
                onClick={onBack}
              />
            )}
            <Text>Mark Lead as Unqualified</Text>
          </HStack>
        </ModalHeader>
        <ModalBody>
          <VStack spacing={4} align="stretch">
            <FormControl isRequired>
              <FormLabel fontWeight="600">Reason (Required)</FormLabel>
              <Textarea
                placeholder="Why is this lead unqualified? (e.g., Budget constraints, Not interested, Already working with competitor, etc.)"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                rows={5}
                autoFocus
                minLength={10}
              />
              <Text fontSize="xs" color="gray.500" mt={1}>
                Minimum 10 characters required
              </Text>
            </FormControl>


          </VStack>
        </ModalBody>
        <ModalFooter>
          <Button
            colorScheme="yellow"
            onClick={handleSubmit}
            isLoading={loading}
            loadingText="Updating..."
          >
            Mark as Unqualified
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}





