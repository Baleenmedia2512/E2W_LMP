﻿'use client';

import {
  Box,
  Heading,
  SimpleGrid,
  Card,
  CardBody,
  CardHeader,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Progress,
  VStack,
  HStack,
  Text,
  Badge,
  Input,
  Button,
  useToast,
  Flex,
  Select,
} from '@chakra-ui/react';
import { useState, useEffect, useMemo, useRef } from 'react';
import useSWR from 'swr';
import { fetcher } from '@/shared/lib/swr';
import { useAuth } from '@/shared/lib/auth/auth-context';
import { loadReportsPersistedFilters, usePersistReportsFilters } from '@/shared/hooks/useReportsFilterPersistence';
import SourceWinAnalysisSection from '@/features/reports/components/SourceWinAnalysisSection';

interface ReportsData {
  totalLeads: number;
  newLeads: number;
  wonDeals: number;
  lostDeals: number;
  unqualifiedLeads: number;
  unreachableLeads: number;
  conversionRate: number;
  avgCallAttempts: number;
  totalCallAttempts: number;
  avgCallDuration: number;
  totalCallDuration: number;
  leadsBySource: Record<string, number>;
  leadsByAgent: Array<{ agent: string; count: number; percentage: number }>;
  leadsByStatus: Record<string, number>;
  leadsByAttempts: Record<string, number>;
  users: Array<{ id: string; name: string }>;
}

export default function ReportsPage() {
  const { user } = useAuth();

  const lockedAgentId = user?.role === 'Agent' && user?.id ? user.id : undefined;
  const initialReportsFiltersRef = useRef(loadReportsPersistedFilters(lockedAgentId));
  const reportsInit = initialReportsFiltersRef.current;

  const [startDate, setStartDate] = useState<string>(reportsInit.startDate);
  const [endDate, setEndDate] = useState<string>(reportsInit.endDate);
  const [dateFilterType, setDateFilterType] = useState<'created' | 'updated'>(reportsInit.dateFilterType);
  const [selectedAgentId, setSelectedAgentId] = useState<string>(reportsInit.selectedAgentId);
  
  // Sorting states
  const [sourceSortOrder, setSourceSortOrder] = useState<string>(reportsInit.sourceSortOrder);
  const [statusSortOrder, setStatusSortOrder] = useState<string>(reportsInit.statusSortOrder);

  usePersistReportsFilters({
    startDate,
    endDate,
    dateFilterType,
    selectedAgentId,
    sourceSortOrder,
    statusSortOrder,
  });

  // Auto-select current user's ID if they are an Agent
  useEffect(() => {
    if (user && user.role === 'Agent') {
      setSelectedAgentId(user.id);
    }
  }, [user]);

  // SWR — cached, re-fetches automatically when filters change
  const agentQuery = selectedAgentId !== 'all' ? `&agentId=${selectedAgentId}` : '';
  const reportsUrl = `/api/reports?startDate=${startDate}&endDate=${endDate}&dateFilterType=${dateFilterType}${agentQuery}`;
  const { data: rawData, isLoading: loading, error: swrError } = useSWR(
    reportsUrl,
    fetcher,
    { keepPreviousData: true, dedupingInterval: 30000, revalidateOnFocus: false }
  );
  const data: ReportsData | null = rawData?.success ? rawData.data : null;
  const error: string | null = swrError || (!rawData?.success && rawData) ? 'Failed to fetch reports' : null;

  const toast = useToast();

  // Memoized sorted sources logic
  const sortedSources = useMemo(() => {
    if (!data || !data.leadsBySource) return [];

    const sourceEntries = Object.entries(data.leadsBySource).map(([source, count]) => {
      const percentage = data.totalLeads > 0 ? Math.round((count / data.totalLeads) * 100 * 100) / 100 : 0;
      return { source, count, percentage };
    });

    return sourceEntries.sort((a, b) => {
      switch (sourceSortOrder) {
        case 'percentage-desc':
          return b.percentage - a.percentage;
        case 'percentage-asc':
          return a.percentage - b.percentage;
        case 'alphabetical-asc':
          return a.source.localeCompare(b.source);
        case 'alphabetical-desc':
          return b.source.localeCompare(a.source);
        default:
          return b.percentage - a.percentage;
      }
    });
  }, [data, sourceSortOrder]);

  // Memoized sorted status logic
  const sortedStatuses = useMemo(() => {
    if (!data || !data.leadsByStatus) return [];

    const statusEntries = Object.entries(data.leadsByStatus).map(([status, count]) => {
      const percentage = data.totalLeads > 0 ? Math.round((count / data.totalLeads) * 100 * 100) / 100 : 0;
      return { status, count, percentage };
    });

    return statusEntries.sort((a, b) => {
      switch (statusSortOrder) {
        case 'percentage-desc':
          return b.percentage - a.percentage;
        case 'percentage-asc':
          return a.percentage - b.percentage;
        case 'alphabetical-asc':
          return a.status.localeCompare(b.status);
        case 'alphabetical-desc':
          return b.status.localeCompare(a.status);
        default:
          return b.percentage - a.percentage;
      }
    });
  }, [data, statusSortOrder]);

  const handleExport = () => {
    toast({
      title: 'Export Feature',
      description: 'Export functionality will be available in future enhancement.',
      status: 'info',
      duration: 3000,
      isClosable: true,
      position: 'top',
    });
  };

  if (loading) {
    return (
      <Box>
        <Heading size={{ base: 'md', md: 'lg' }} mb={6}>Reports & Analytics</Heading>
        <Text color="gray.500">Loading reports...</Text>
      </Box>
    );
  }

  if (error || !data) {
    return (
      <Box>
        <Heading size={{ base: 'md', md: 'lg' }} mb={6}>Reports & Analytics</Heading>
        <Box bg="red.50" p={4} borderRadius="lg" color="red.700">
          {error || 'Failed to load reports'}
        </Box>
      </Box>
    );
  }

  return (
    <Box>
      <Flex justify="space-between" align="center" mb={{ base: 4, md: 6 }} flexWrap="wrap" gap={3}>
        <Heading size={{ base: 'md', md: 'lg' }}>
          Reports & Analytics
        </Heading>
        <Button 
          colorScheme="blue" 
          size={{ base: 'sm', md: 'md' }}
          onClick={handleExport}
          variant="outline"
          w={{ base: 'full', sm: 'auto' }}
        >
          Export Report
        </Button>
      </Flex>

      {/* Date Range Filter */}
      <Card mb={6}>
        <CardBody>
          <VStack spacing={4} align="stretch">
            <Flex gap={3} flexWrap="wrap" align="flex-end">
              <Box flex={{ base: '1 1 100%', sm: '1 1 auto' }} minW={{ sm: '140px' }}>
                <Text fontSize="sm" fontWeight="semibold" mb={2}>Start Date</Text>
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  max={endDate}
                  size={{ base: 'sm', md: 'md' }}
                />
              </Box>
              <Box flex={{ base: '1 1 100%', sm: '1 1 auto' }} minW={{ sm: '140px' }}>
                <Text fontSize="sm" fontWeight="semibold" mb={2}>End Date</Text>
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  min={startDate}
                  size={{ base: 'sm', md: 'md' }}
                />
              </Box>
              <Box flex={{ base: '1 1 100%', sm: '0 0 auto' }}>
                <Text fontSize="sm" fontWeight="semibold" mb={2}>Filter By</Text>
                <Flex gap={2} flexWrap="wrap">
                  <Button
                    size={{ base: 'sm', md: 'md' }}
                    colorScheme={dateFilterType === 'created' ? 'blue' : 'gray'}
                    variant={dateFilterType === 'created' ? 'solid' : 'outline'}
                    onClick={() => setDateFilterType('created')}
                    flex={{ base: '1 1 auto', sm: '0 0 auto' }}
                  >
                    Created Date
                  </Button>
                  <Button
                    size={{ base: 'sm', md: 'md' }}
                    colorScheme={dateFilterType === 'updated' ? 'blue' : 'gray'}
                    variant={dateFilterType === 'updated' ? 'solid' : 'outline'}
                    onClick={() => setDateFilterType('updated')}
                    flex={{ base: '1 1 auto', sm: '0 0 auto' }}
                  >
                    Updated Date
                  </Button>
                </Flex>
              </Box>
              <Box flex={{ base: '1 1 100%', sm: '1 1 auto' }} minW={{ sm: '180px' }}>
                <Text fontSize="sm" fontWeight="semibold" mb={2}>Agent Filter</Text>
                <Select
                  value={selectedAgentId}
                  onChange={(e) => setSelectedAgentId(e.target.value)}
                  size={{ base: 'sm', md: 'md' }}
                  bg="white"
                  isDisabled={user?.role === 'Agent'}
                >
                  <option value="all">All Agents</option>
                  {data?.users?.map((agent) => (
                    <option key={agent.id} value={agent.id}>
                      {agent.name}
                    </option>
                  ))}
                </Select>
              </Box>
            </Flex>
            <Box>
              <Text fontSize="sm" color="gray.600">
                Showing leads {dateFilterType === 'created' ? 'created' : 'updated'} from {new Date(startDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: '2-digit' }).replace(/\//g, '-')} to {new Date(endDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: '2-digit' }).replace(/\//g, '-')}
                {selectedAgentId !== 'all' && data?.users && (
                  <Badge ml={2} colorScheme="purple">
                    {data.users.find(u => u.id === selectedAgentId)?.name || 'Selected Agent'}
                  </Badge>
                )}
              </Text>
            </Box>
          </VStack>
        </CardBody>
      </Card>

      {/* Key Metrics */}
      <SimpleGrid columns={{ base: 1, sm: 2, lg: 4 }} spacing={4} mb={6}>
        <Card bg="blue.50" borderWidth="2px" borderColor="blue.200">
          <CardBody>
            <Stat>
              <StatLabel color="blue.800">Total Leads</StatLabel>
              <StatNumber color="blue.900">{data.totalLeads}</StatNumber>
              <StatHelpText color="blue.700">
                {selectedAgentId === 'all' ? 'In selected range' : 'For selected agent'}
              </StatHelpText>
            </Stat>
          </CardBody>
        </Card>

        <Card bg={data.conversionRate >= 50 ? 'green.50' : 'red.50'} borderWidth="2px" borderColor={data.conversionRate >= 50 ? 'green.200' : 'red.200'}>
          <CardBody>
            <Stat>
              <StatLabel color={data.conversionRate >= 50 ? 'green.800' : 'red.800'}>Conversion Rate</StatLabel>
              <StatNumber color={data.conversionRate >= 50 ? 'green.900' : 'red.900'}>{data.conversionRate.toFixed(2)}%</StatNumber>
              <StatHelpText color={data.conversionRate >= 50 ? 'green.700' : 'red.700'}>
                Won / Total leads
              </StatHelpText>
            </Stat>
          </CardBody>
        </Card>

        <Card bg="gray.50" borderWidth="2px" borderColor="gray.200">
          <CardBody>
            <Stat>
              <StatLabel color="gray.600">Total Revenue</StatLabel>
              <StatNumber color="gray.700">-</StatNumber>
              <StatHelpText color="gray.500">Future enhancement</StatHelpText>
            </Stat>
          </CardBody>
        </Card>

        <Card bg="purple.50" borderWidth="2px" borderColor="purple.200">
          <CardBody>
            <Stat>
              <StatLabel color="purple.800">Avg Call Duration</StatLabel>
              <StatNumber color="purple.900">
                {Math.floor(data.avgCallDuration / 60)}:{(data.avgCallDuration % 60).toString().padStart(2, '0')}
              </StatNumber>
              <StatHelpText color="purple.700">
                {data.avgCallDuration > 0 ? 'minutes:seconds' : 'No data'}
              </StatHelpText>
            </Stat>
          </CardBody>
        </Card>
      </SimpleGrid>

      {/* Secondary Metrics */}
      <SimpleGrid columns={{ base: 1, sm: 2, md: 3, lg: 5 }} spacing={4} mb={6}>
        <Card bg="blue.50" borderWidth="1px" borderColor="blue.100">
          <CardBody>
            <Stat>
              <StatLabel fontSize="sm" color="blue.700">New Leads</StatLabel>
              <StatNumber fontSize="2xl" color="blue.900">{data.newLeads}</StatNumber>
            </Stat>
          </CardBody>
        </Card>

        <Card bg="green.50" borderWidth="1px" borderColor="green.100">
          <CardBody>
            <Stat>
              <StatLabel fontSize="sm" color="green.700">Won Deals</StatLabel>
              <StatNumber fontSize="2xl" color="green.700">{data.wonDeals}</StatNumber>
            </Stat>
          </CardBody>
        </Card>

        <Card bg="red.50" borderWidth="1px" borderColor="red.100">
          <CardBody>
            <Stat>
              <StatLabel fontSize="sm" color="red.700">Lost Deals</StatLabel>
              <StatNumber fontSize="2xl" color="red.700">{data.lostDeals}</StatNumber>
            </Stat>
          </CardBody>
        </Card>

        <Card bg="orange.50" borderWidth="1px" borderColor="orange.100">
          <CardBody>
            <Stat>
              <StatLabel fontSize="sm" color="orange.700">Unqualified</StatLabel>
              <StatNumber fontSize="2xl" color="orange.700">{data.unqualifiedLeads}</StatNumber>
            </Stat>
          </CardBody>
        </Card>

        <Card bg="gray.50" borderWidth="1px" borderColor="gray.100">
          <CardBody>
            <Stat>
              <StatLabel fontSize="sm" color="gray.700">Unreachable</StatLabel>
              <StatNumber fontSize="2xl" color="gray.700">{data.unreachableLeads}</StatNumber>
            </Stat>
          </CardBody>
        </Card>
      </SimpleGrid>

      <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6} mb={6}>
        {/* Leads by Source */}
        <Card>
          <CardHeader>
            <Flex justify="space-between" align="center">
              <Heading size="md">Contact by Source</Heading>
              <Select 
                w="160px" 
                size="sm" 
                value={sourceSortOrder} 
                onChange={(e) => setSourceSortOrder(e.target.value)}
                bg="white"
              >
                <option value="percentage-desc">Highest % First</option>
                <option value="percentage-asc">Lowest % First</option>
                <option value="alphabetical-asc">A to Z</option>
                <option value="alphabetical-desc">Z to A</option>
              </Select>
            </Flex>
          </CardHeader>
          <CardBody>
            <VStack spacing={3} align="stretch">
              {sortedSources.map(({ source, count, percentage }) => (
                <Box key={source}>
                  <HStack justify="space-between" mb={1}>
                    <Text fontSize="sm" fontWeight="medium" textTransform="capitalize">{source}</Text>
                    <HStack spacing={2}>
                      <Text fontSize="sm" color="gray.600">{count} leads</Text>
                      <Badge colorScheme="blue">{percentage}%</Badge>
                    </HStack>
                  </HStack>
                  <Progress 
                    value={percentage} 
                    size="sm" 
                    colorScheme="blue" 
                    borderRadius="full"
                  />
                </Box>
              ))}
              {sortedSources.length === 0 && (
                <Text fontSize="sm" color="gray.500" textAlign="center" py={4}>No source data available</Text>
              )}
            </VStack>
          </CardBody>
        </Card>

        {/* Contact by Status Distribution - Updated with manual sort identical to Source */}
        <Card>
          <CardHeader>
            <Flex justify="space-between" align="center">
              <Heading size="md">Contact by Status</Heading>
              <Select 
                w="160px" 
                size="sm" 
                value={statusSortOrder} 
                onChange={(e) => setStatusSortOrder(e.target.value)}
                bg="white"
              >
                <option value="percentage-desc">Highest % First</option>
                <option value="percentage-asc">Lowest % First</option>
                <option value="alphabetical-asc">A to Z</option>
                <option value="alphabetical-desc">Z to A</option>
              </Select>
            </Flex>
          </CardHeader>
          <CardBody>
            <VStack spacing={3} align="stretch">
              {sortedStatuses.map(({ status, count, percentage }) => {
                const colorScheme = status === 'won' ? 'green' : status === 'lost' ? 'red' : status === 'qualified' ? 'purple' : 'blue';
                return (
                  <Box key={status}>
                    <HStack justify="space-between" mb={1}>
                      <Badge colorScheme={colorScheme} textTransform="capitalize">{status}</Badge>
                      <HStack spacing={2}>
                        <Text fontSize="sm" color="gray.600">{count} leads</Text>
                        <Badge>{percentage}%</Badge>
                      </HStack>
                    </HStack>
                    <Progress 
                      value={percentage} 
                      size="sm" 
                      colorScheme={colorScheme} 
                      borderRadius="full"
                    />
                  </Box>
                );
              })}
              {sortedStatuses.length === 0 && (
                <Text fontSize="sm" color="gray.500" textAlign="center" py={4}>No status data available</Text>
              )}
            </VStack>
          </CardBody>
        </Card>
      </SimpleGrid>

      <SourceWinAnalysisSection
        startDate={startDate}
        endDate={endDate}
        dateFilterType={dateFilterType}
        selectedAgentId={selectedAgentId}
      />

      {/* Call Attempts Distribution */}
      <Card mb={6}>
        <CardHeader>
          <Heading size="md">Call Attempts Distribution</Heading>
          <Text fontSize="sm" color="gray.600" mt={1}>
            Track follow-through and persistence across leads
          </Text>
        </CardHeader>
        <CardBody>
          <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={4}>
            {Object.entries(data.leadsByAttempts).map(([range, count]) => {
              const percentage = data.totalLeads > 0 ? Math.round((count / data.totalLeads) * 100 * 100) / 100 : 0;
              const colorScheme = range === '7+' ? 'red' : range === '4-6' ? 'orange' : range === '1-3' ? 'blue' : 'gray';
              return (
                <Box key={range}>
                  <VStack align="stretch" spacing={2}>
                    <HStack justify="space-between">
                      <Badge colorScheme={colorScheme} fontSize="md" px={2} py={1}>
                        {range === '0' ? 'No Calls' : `${range} Calls`}
                      </Badge>
                      <Text fontWeight="bold" fontSize="xl">{count}</Text>
                    </HStack>
                    <Progress 
                      value={percentage} 
                      size="md" 
                      colorScheme={colorScheme} 
                      borderRadius="full"
                    />
                    <Text fontSize="xs" color="gray.600" textAlign="center">
                      {percentage}% of total leads
                    </Text>
                  </VStack>
                </Box>
              );
            })}
          </SimpleGrid>
        </CardBody>
      </Card>

      {/* Leads by Agent Table */}
      <Card>
        <CardHeader>
          <Heading size={{ base: 'sm', md: 'md' }}>Leads by Agent</Heading>
        </CardHeader>
        <CardBody p={{ base: 0, md: 4 }} pt={{ base: 0, md: 0 }}>
          <Box overflowX="auto" sx={{ WebkitOverflowScrolling: 'touch' }}>
          <Table variant="simple" size={{ base: 'sm', md: 'md' }} minW="400px">
            <Thead>
              <Tr>
                <Th>Agent Name</Th>
                <Th isNumeric>Lead Count</Th>
                <Th isNumeric>Percentage</Th>
              </Tr>
            </Thead>
            <Tbody>
              {data.leadsByAgent.map(({ agent, count, percentage }) => (
                <Tr key={agent}>
                  <Td fontWeight="medium">{agent}</Td>
                  <Td isNumeric>{count}</Td>
                  <Td isNumeric>
                    <HStack justify="flex-end" spacing={2}>
                      <Badge colorScheme="blue">{percentage}%</Badge>
                      <Progress 
                        value={percentage} 
                        size="sm" 
                        colorScheme="blue" 
                        w={{ base: '60px', md: '100px' }}
                        borderRadius="full"
                      />
                    </HStack>
                  </Td>
                </Tr>
              ))}
              {data.leadsByAgent.length === 0 && (
                <Tr>
                  <Td colSpan={3} textAlign="center" py={4}>
                    <Text fontSize="sm" color="gray.500">No agent data available</Text>
                  </Td>
                </Tr>
              )}
            </Tbody>
          </Table>
          </Box>
        </CardBody>
      </Card>
    </Box>
  );
}